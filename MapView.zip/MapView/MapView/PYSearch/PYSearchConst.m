//
//  GitHub: https://github.com/iphone5solo/PYSearch
//  Created by CoderKo1o.
//  Copyright © 2016 iphone5solo. All rights reserved.
//

#import <UIKit/UIKit.h>

NSString *const PYSearchSearchPlaceholderText = @"PYSearchSearchPlaceholderText";
NSString *const PYSearchHotSearchText = @"PYSearchHotSearchText";
NSString *const PYSearchSearchHistoryText = @"PYSearchSearchHistoryText";
NSString *const PYSearchEmptySearchHistoryText = @"PYSearchEmptySearchHistoryText";

NSString *const PYSearchEmptyButtonText = @"PYSearchEmptyButtonText";
NSString *const PYSearchEmptySearchHistoryLogText = @"PYSearchEmptySearchHistoryLogText";
NSString *const PYSearchCancelButtonText = @"PYSearchCancelButtonText";
