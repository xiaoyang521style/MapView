//
//  MapSearchViewController.m
//  位置搜索
//
//  Created by 赵阳 on 2017/5/24.
//  Copyright © 2017年 赵阳. All rights reserved.
//
#define kScreenW [UIScreen mainScreen].bounds.size.width
#define kScreenH [UIScreen mainScreen].bounds.size.height

#define kTabBarH        49.0f
#define kStatusBarH     20.0f
#define kNavigationBarH 44.0f


#define TableViewCellDequeueInit(__INDETIFIER__) [tableView dequeueReusableCellWithIdentifier:(__INDETIFIER__)];

#define TableViewCellDequeue(__CELL__,__CELLCLASS__,__INDETIFIER__) \
{\
if (__CELL__ == nil) {\
__CELL__ = [[__CELLCLASS__ alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:__INDETIFIER__];\
}\
}


#import "MapSearchViewController.h"
#import <AMapFoundationKit/AMapFoundationKit.h>

#import <AMapSearchKit/AMapSearchKit.h>
#import "MapView.h"
@interface MapSearchViewController ()<UITableViewDelegate,UITableViewDataSource,AMapSearchDelegate>
@property(nonatomic,strong)UITableView *tabelView;
@property(nonatomic,strong)NSMutableArray *dataSoucer;
@property (nonatomic, strong)AMapSearchAPI *search;
@property(nonatomic, strong)UIView *bootomView;
@end

@implementation MapSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
    self.search = [[AMapSearchAPI alloc] init];
    self.search.delegate = self;
    AMapPOIKeywordsSearchRequest *request = [[AMapPOIKeywordsSearchRequest alloc] init];
    request.keywords = self.searchStr;
    request.requireExtension    = YES;
    [self.search AMapPOIKeywordsSearch:request];
    // Do any additional setup after loading the view.
}
-(void)setupUI{
    [self setNavigationBackBtn];
    self.title = @"地点搜索结果";
    [self.view addSubview:self.tabelView];
}
-(void)setNavigationBackBtn {
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"back_mine"] style:UIBarButtonItemStylePlain target:self action:@selector(backClick)];
    
}
-(void)backClick{
    [self.navigationController popViewControllerAnimated:YES];
}
-(NSMutableArray *)dataSoucer{
    if (_dataSoucer == nil) {
        _dataSoucer = [NSMutableArray new];
    }
    return _dataSoucer;
}

- (void)onPOISearchDone:(AMapPOISearchBaseRequest *)request response:(AMapPOISearchResponse *)response
{
    if (response.pois.count == 0)
    {
        return;
    }
  
    for (AMapPOI *poi in response.pois) {
        [self.dataSoucer addObject:poi];
    }
    
    [self.tabelView reloadData];
 
    
        //解析response获取POI信息，具体解析见 Demo
}

-(UITableView *)tabelView{
    if (_tabelView == nil) {
        _tabelView = [[UITableView alloc]initWithFrame:CGRectMake(0, kNavigationBarH + kStatusBarH, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height -kNavigationBarH + kStatusBarH) style:UITableViewStylePlain];
        _tabelView.delegate = self;
        _tabelView.dataSource = self;
        _tabelView.tableFooterView = [[UIView alloc]init];
    }
    return _tabelView;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSoucer.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = TableViewCellDequeueInit(@"mapCell");
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"mapCell"];
        
    }
    AMapPOI *poi = self.dataSoucer[indexPath.row];
    cell.textLabel.text = poi.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ %@ %@ %@",poi.province,poi.city,poi.district,poi.address];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [self.delegate showInMap:self.dataSoucer[indexPath.row]];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
